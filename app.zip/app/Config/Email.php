<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Email extends BaseConfig
{
    // Gmail OAuth2 Configuration
    public string $fromEmail = 'masputramedia.center@gmail.com'; // Gmail Anda
    public string $fromName = 'Exputra Billing System';
    public string $recipients = '';
    public string $userAgent = 'CodeIgniter';
    public string $protocol = 'smtp';
    public string $mailPath = '/usr/sbin/sendmail';
    
    // Gmail SMTP Settings
    public string $SMTPHost = 'smtp.gmail.com';
    public string $SMTPUser = 'masputramedia.center@gmail.com'; // Gmail Anda
    public string $SMTPPass = ''; // Akan diisi dengan OAuth token
    public int $SMTPPort = 587;
    public int $SMTPTimeout = 30;
    public bool $SMTPKeepAlive = false;
    public string $SMTPCrypto = 'tls';
    
    public bool $wordWrap = true;
    public int $wrapChars = 76;
    public string $mailType = 'html';
    public string $charset = 'UTF-8';
    public bool $validate = true;
    public int $priority = 3;
    public string $CRLF = "\r\n";
    public string $newline = "\r\n";
    public bool $BCCBatchMode = false;
    public int $BCCBatchSize = 200;
    public bool $DSN = false;

    // OAuth2 Settings
    public string $googleClientId = '412753326860-60oignu4f53cmg26f71saobtq0s9pqeg.apps.googleusercontent.com';
    public string $googleClientSecret = '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';
    public string $googleRedirectUri = 'https://exputra.cloud/auth/gmail-callback';
}